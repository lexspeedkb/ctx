<?php
return [
    'database.host' => 'localhost',
    'database.name' => 'cortex',
    'database.user' => 'root',
    'database.pass' => 'root',

    'firewall.requests_per_minute' => 100,
];