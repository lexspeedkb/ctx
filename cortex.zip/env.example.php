<?php
return [
    'database.host' => '',
    'database.name' => '',
    'database.user' => '',
    'database.pass' => '',

    'firewall.requests_per_minute' => 100,
];