<h1><?=$header?></h1>
<h2><?=$subheader?></h2>
<form>
    <input type="button" value="Go back!" onclick="history.back()">
</form>