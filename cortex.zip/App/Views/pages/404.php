<h1>404</h1>
<h2><a href="/">Go home</a></h2>