<?php

namespace App\Classes;

use App\Entities\OrderToGoodEntity;
use App\Interfaces\ClassInterface;

class OrdersToGoods extends OrderToGoodEntity implements ClassInterface
{
    use BaseClass;
}